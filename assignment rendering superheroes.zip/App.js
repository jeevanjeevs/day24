


import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeComp from './components/screens/homecomp';
import SuperheroComp from './components/screens/herodeatils';


 
 
 
let Stack = createNativeStackNavigator ();
 
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name='Home' component={HomeComp}/>
        <Stack.Screen name="SuperheroComp" component={SuperheroComp} />
      </Stack.Navigator>
     
 
    </NavigationContainer>
  );
}