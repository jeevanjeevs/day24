import React from "react";
import { ImageBackground, SafeAreaView, ScrollView, Text, View } from "react-native";
import { Header } from "./components/header";
import { Footer } from "./components/footer";

const naturelist1 = [
  { title: "Place1", poster: { uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSeJVxKk1WJpCAldiw8qG6hSnltqORTavrt5o8OhgrpJFAeKMrZJy7LpAQFjj09wICYKkI&usqp=CAU" } },
  { title: "Place2", poster: { uri: "https://w.forfun.com/fetch/53/5324723dbd76404c2cb12c0109e913c4.jpeg" } },
  { title: "Place3", poster: { uri: "https://wallpapers.com/images/hd/cute-black-cat-whiskers-t4u9dw0az4ohfcxt.jpg" } },
];

const naturelist2 = [
  { title: "place4", poster: { uri: "https://c4.wallpaperflare.com/wallpaper/814/493/259/cat-teeth-eyes-black-background-wallpaper-thumb.jpg" } },
  { title: "place5", poster: { uri: "https://c4.wallpaperflare.com/wallpaper/640/1007/630/cat-paws-mad-wallpaper-preview.jpg" } },
  { title: "place6", poster: { uri: "https://c1.wallpaperflare.com/preview/993/430/482/cat-pet-black-evil-thumbnail.jpg" } },
];

export default App = () => {
  return (
    <SafeAreaView>
      <Header />
      <ScrollView style={{ height: "80%" }}>
        <View style={{ flexDirection: "row", flexWrap: "wrap", marginLeft: "5%" }}>
          {naturelist1.map((val1, idx1) => (
            <View key={idx1} style={{ width: "50%", marginTop: "5%" }}>
              <ImageBackground source={val1.poster} style={{ width: 150, height: 300, justifyContent: "flex-end" }}>
                <Text style={{ color: "white", textAlign: "center", padding: 10, fontSize:25}}>{val1.title}</Text>
              </ImageBackground>
            </View>
          ))}
          {naturelist2.map((val2, idx2) => (
            <View key={idx2} style={{ width: "50%", marginTop: "5%" }}>
              <ImageBackground source={val2.poster} style={{ width: 150, height: 300, justifyContent: "flex-end" }}>
                <Text style={{ color: "white", textAlign: "center", padding: 10, fontSize:25}}>{val2.title}</Text>
              </ImageBackground>
            </View>
          ))}
        </View>
      </ScrollView>
      <Footer />
    </SafeAreaView>
  );
};
