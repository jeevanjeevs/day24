import { Text, View } from "react-native"

export let Footer = ()=>{
    return <View style={{height:"10%",backgroundColor:"coral"}}>
      <Text style={{fontSize:20,margin:"5%", textAlign: "center"}}>Jeevan's Footer</Text>
    </View>
  
  }