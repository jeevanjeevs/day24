import { Text, View } from "react-native"

export let Header = ()=>{
    return <View style={{height:"10%",backgroundColor:"yellow"}}> 
      <Text style={{fontSize:20,margin:"5%", textAlign: "center"}}>Jeevan's Header</Text>
    </View>
  
  }